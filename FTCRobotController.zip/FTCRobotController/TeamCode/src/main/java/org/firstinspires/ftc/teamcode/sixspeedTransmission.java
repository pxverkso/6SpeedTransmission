package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;

@TeleOp(name = "sixspeedtransmission")
public class sixspeedTransmission extends LinearOpMode {

    private DcMotor motor1;
    private DcMotor motor2;
    private Servo C1;
    private Servo C2;
    private Servo C3;
    private Servo C4;
    private Servo C5;

    private int xIndex = 0;
    private int yIndex = 0;

    private boolean prevX = false;
    private boolean prevY = false;

    @Override
    public void runOpMode() {
        motor1 = hardwareMap.get(DcMotor.class, "motor1");
        motor2 = hardwareMap.get(DcMotor.class, "motor2");
        C1 = hardwareMap.get(Servo.class, "C1");
        C2 = hardwareMap.get(Servo.class, "C2");
        C3 = hardwareMap.get(Servo.class, "C3");
        C4 = hardwareMap.get(Servo.class, "C4");
        C5 = hardwareMap.get(Servo.class, "C5");

        motor1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motor2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        motor1.setDirection(DcMotorSimple.Direction.FORWARD);
        motor2.setDirection(DcMotorSimple.Direction.FORWARD);

        boolean ramping = false;
        boolean prevA = false;
        double motorPower = 0.0;
        long lastRampTime = 0;

        waitForStart();

        while (opModeIsActive()) {
            boolean currentA = gamepad1.a;
            boolean currentX = gamepad1.x;
            boolean currentY = gamepad1.y;

            if (currentX && !prevX) {
                xIndex = (xIndex + 1) % 6;

                if (xIndex == 0) {
                    C1.setPosition(0.4);
                    C2.setPosition(0.65);
                    C3.setPosition(0.15);
                    C4.setPosition(0.33);
                    C5.setPosition(0.5);
                } else if (xIndex == 1) {
                    C1.setPosition(0.52);
                    C2.setPosition(0.5);
                    C3.setPosition(0.5);
                    C4.setPosition(0.0);
                    C5.setPosition(0.8);
                } else if (xIndex == 2) {
                    C1.setPosition(0.4);
                    C2.setPosition(0.65);
                    C3.setPosition(0.15);
                    C4.setPosition(0.33);
                    C5.setPosition(0.5);
                } else if (xIndex == 3) {
                    C1.setPosition(0.52);
                    C2.setPosition(0.5);
                    C3.setPosition(0.5);
                    C4.setPosition(0.0);
                    C5.setPosition(0.8);
                } else if (xIndex == 4) {
                    C1.setPosition(0.4);
                    C2.setPosition(0.65);
                    C3.setPosition(0.15);
                    C4.setPosition(0.33);
                    C5.setPosition(0.5);
                } else {
                    C1.setPosition(0.52);
                    C2.setPosition(0.5);
                    C3.setPosition(0.5);
                    C4.setPosition(0.0);
                    C5.setPosition(0.8);
                }
            }

            if (currentA && !prevA) {
                ramping = true;
                motorPower = 0.0;
                lastRampTime = System.currentTimeMillis();
                motor1.setPower(motorPower);
                motor2.setPower(motorPower);
            }

            if (!currentA) {
                ramping = false;
                motorPower = 0.0;
                motor1.setPower(0.0);
                motor2.setPower(0.0);
            }

            if (ramping) {
                long now = System.currentTimeMillis();

                if (now - lastRampTime >= 5000) {
                    motorPower += 0.2;
                    if (motorPower > 1.0) motorPower = 1.0;

                    motor1.setPower(motorPower);
                    motor2.setPower(motorPower);
                    lastRampTime = now;
                }
            }

            telemetry.addData("Ramping", ramping);
            telemetry.addData("Motor Power", motorPower);
            telemetry.addData("Servo C1", C1.getPosition());
            telemetry.addData("Servo C2", C2.getPosition());
            telemetry.addData("Servo C3", C3.getPosition());
            telemetry.addData("Servo C4", C4.getPosition());
            telemetry.addData("Servo C5", C5.getPosition());
            telemetry.addData("X State", xIndex);
            telemetry.addData("Y State", yIndex);
            telemetry.update();

            prevA = currentA;
            prevX = currentX;
            prevY = currentY;

            sleep(20);
        }

        motor1.setPower(0.0);
        motor2.setPower(0.0);
    }
}