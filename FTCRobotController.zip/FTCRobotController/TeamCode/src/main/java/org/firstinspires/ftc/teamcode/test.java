package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.Servo;

@TeleOp(name = "Servo Test", group = "Test")
public class test extends OpMode {

    private Servo C1;
    private double position = 0.6;

    @Override
    public void init() {
        C1 = hardwareMap.get(Servo.class, "C2");
        C1.setPosition(position);
    }

    @Override
    public void loop() {
        if (gamepad1.a) position = 0.6;
        if (gamepad1.b) position = 0.5;

        if (gamepad1.dpad_up) position += 0.01;
        if (gamepad1.dpad_down) position -= 0.01;

        if (position < 0.0) position = 0.0;
        if (position > 1.0) position = 1.0;

        C1.setPosition(position);

        telemetry.addData("Servo Position", C1.getPosition());
        telemetry.addData("Target", position);
        telemetry.update();
    }
}